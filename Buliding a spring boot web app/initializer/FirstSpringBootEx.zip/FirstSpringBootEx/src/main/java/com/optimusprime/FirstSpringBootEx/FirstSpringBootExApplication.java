package com.optimusprime.FirstSpringBootEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootExApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootExApplication.class, args);
	}
}
